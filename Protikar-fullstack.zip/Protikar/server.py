from __future__ import annotations

import asyncio
import hashlib
import hmac
import os
import secrets
import shutil
import subprocess
import tempfile
import time
import uuid
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

import numpy as np
import soundfile as sf
import torch
import torch.nn as nn
from fastapi import FastAPI, File, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel
from transformers import AutoImageProcessor, AutoModelForImageClassification, Wav2Vec2Model
from starlette.concurrency import run_in_threadpool

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
MAX_UPLOAD = int(os.getenv("MAX_UPLOAD_BYTES", str(50 * 1024 * 1024)))
SHARE_TTL = int(os.getenv("LOCATION_SHARE_TTL_SECONDS", str(2 * 60 * 60)))
IMAGE_MODEL_ID = os.getenv("IMAGE_MODEL_ID", "agasta/virtus")
PELLA_WEIGHTS = Path(os.getenv("PELLA_WEIGHTS", str(ROOT / "models" / "pellav2_detector.pt")))
DEVICE = "cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu")

app = FastAPI(title="Protikar API", version="1.0.0")
app.mount("/static", StaticFiles(directory=STATIC), name="static")
Image.MAX_IMAGE_PIXELS = 40_000_000


@app.middleware("http")
async def privacy_headers(request: Request, call_next: Any) -> Any:
    if request.url.path == "/api/detect":
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > MAX_UPLOAD + 1024 * 1024:
            return JSONResponse(status_code=413, content={"detail": f"File is larger than {MAX_UPLOAD // (1024 * 1024)} MB."})
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["X-Frame-Options"] = "DENY"
    return response

_image_model: Any = None
_image_processor: Any = None
_image_lock = asyncio.Lock()
_audio_model: Any = None
_audio_lock = asyncio.Lock()
_shares: dict[str, dict[str, Any]] = {}
_shares_lock = asyncio.Lock()
_rate_events: dict[str, deque[float]] = defaultdict(deque)


class LocationCreate(BaseModel):
    consent: bool


class Pellav2Detector(nn.Module):
    """Pellav2 research model architecture from its published model card."""

    def __init__(self) -> None:
        super().__init__()
        self.backbone = Wav2Vec2Model.from_pretrained("facebook/wav2vec2-xls-r-300m")
        self.layer_weights = nn.Parameter(torch.zeros(self.backbone.config.num_hidden_layers + 1))
        self.head = nn.Linear(self.backbone.config.hidden_size, 1)

    def forward(self, samples: torch.Tensor) -> torch.Tensor:
        hidden_states = self.backbone(samples, output_hidden_states=True).hidden_states
        weights = torch.softmax(self.layer_weights, dim=0)
        fused = torch.stack(hidden_states).mul(weights[:, None, None, None]).sum(0).mean(dim=1)
        return self.head(fused).squeeze(-1)


def _clean_expired_shares() -> None:
    now = time.time()
    for share_id in list(_shares):
        if now >= _shares[share_id]["expires_at"]:
            _shares.pop(share_id, None)


async def _send_viewers(share: dict[str, Any], message: dict[str, Any]) -> None:
    disconnected = []
    for websocket in share["viewers"]:
        try:
            await websocket.send_json(message)
        except Exception:
            disconnected.append(websocket)
    for websocket in disconnected:
        share["viewers"].discard(websocket)


async def _load_image_model() -> tuple[Any, Any]:
    global _image_model, _image_processor
    if _image_model is None:
        async with _image_lock:
            if _image_model is None:
                try:
                    processor = await asyncio.to_thread(AutoImageProcessor.from_pretrained, IMAGE_MODEL_ID)
                    model = await asyncio.to_thread(AutoModelForImageClassification.from_pretrained, IMAGE_MODEL_ID)
                    model = await asyncio.to_thread(lambda: model.to(DEVICE).eval())
                except Exception as exc:
                    raise HTTPException(503, "Image detector could not load. Check model access and server memory.") from exc
                _image_processor, _image_model = processor, model
    return _image_processor, _image_model


async def _load_audio_model() -> Any:
    global _audio_model
    if not PELLA_WEIGHTS.is_file():
        raise HTTPException(503, "Audio detector is not configured. Download its weights and set PELLA_WEIGHTS.")
    if _audio_model is None:
        async with _audio_lock:
            if _audio_model is None:
                try:
                    model = await asyncio.to_thread(Pellav2Detector)
                    state = await asyncio.to_thread(torch.load, PELLA_WEIGHTS, map_location="cpu", weights_only=True)
                    if isinstance(state, dict) and "state_dict" in state:
                        state = state["state_dict"]
                    model.load_state_dict(state, strict=True)
                    _audio_model = await asyncio.to_thread(lambda: model.to(DEVICE).eval())
                except Exception as exc:
                    raise HTTPException(503, "Audio detector weights could not be loaded.") from exc
    return _audio_model


def _image_scores(image: Image.Image, processor: Any, model: Any) -> dict[str, Any]:
    batch = processor(images=image.convert("RGB"), return_tensors="pt")
    batch = {name: tensor.to(DEVICE) for name, tensor in batch.items()}
    with torch.inference_mode():
        logits = model(**batch).logits[0]
        probabilities = torch.softmax(logits, dim=-1).detach().cpu().tolist()
    labels = model.config.id2label
    scores = [{"label": str(labels.get(index, labels.get(str(index), f"class_{index}"))), "score": float(score)} for index, score in enumerate(probabilities)]
    fake_score = next((entry["score"] for entry in scores if any(tag in entry["label"].lower() for tag in ("fake", "deepfake", "synthetic"))), None)
    if fake_score is None:
        raise HTTPException(503, "The selected image model does not expose a recognizable synthetic-media label.")
    return {"synthetic_media_score": fake_score, "class_scores": scores}


async def _analyze_image(path: Path) -> dict[str, Any]:
    processor, model = await _load_image_model()
    try:
        with Image.open(path) as image:
            image.load()
            return await run_in_threadpool(_image_scores, image.copy(), processor, model)
    except (UnidentifiedImageError, Image.DecompressionBombError, OSError) as exc:
        raise HTTPException(415, "The uploaded image could not be decoded.") from exc


async def _analyze_audio(path: Path, workdir: Path) -> dict[str, Any]:
    model = await _load_audio_model()
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise HTTPException(503, "ffmpeg is required to decode and resample audio.")
    wav_path = workdir / "audio-16k-mono.wav"
    try:
        await asyncio.to_thread(subprocess.run, [ffmpeg, "-v", "error", "-y", "-i", str(path), "-vn", "-ac", "1", "-ar", "16000", str(wav_path)], check=True, capture_output=True, timeout=90)
        samples, sample_rate = sf.read(wav_path, dtype="float32")
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, RuntimeError, ValueError, OSError) as exc:
        raise HTTPException(415, "Could not decode an audio track from this file.") from exc
    if sample_rate != 16000 or samples.size == 0:
        raise HTTPException(415, "Could not decode usable 16 kHz audio.")
    if samples.ndim > 1:
        samples = samples.mean(axis=1)
    crop_size = 4 * sample_rate
    if len(samples) >= crop_size:
        start = (len(samples) - crop_size) // 2
        samples = samples[start:start + crop_size]
    else:
        samples = np.pad(samples, (0, crop_size - len(samples)))
    samples = (samples - samples.mean()) / (samples.std() + 1e-7)
    tensor = torch.from_numpy(samples).unsqueeze(0).to(DEVICE)
    score = await run_in_threadpool(_audio_score, model, tensor)
    return {"synthetic_speech_score": score, "sampled_audio_seconds": min(4, len(samples) / sample_rate)}


async def _analyze_video(path: Path, workdir: Path) -> dict[str, Any]:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise HTTPException(503, "ffmpeg is required to inspect video frames and audio.")
    frame_dir = workdir / "frames"
    frame_dir.mkdir()
    try:
        await asyncio.to_thread(subprocess.run, [ffmpeg, "-v", "error", "-y", "-i", str(path), "-vf", "fps=1/3,scale=720:-1", "-frames:v", "8", str(frame_dir / "frame-%02d.jpg")], check=True, capture_output=True, timeout=120)
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        raise HTTPException(415, "Could not decode video frames.") from exc
    frame_paths = sorted(frame_dir.glob("frame-*.jpg"))
    if not frame_paths:
        raise HTTPException(415, "No video frames could be decoded.")
    processor, model = await _load_image_model()
    frame_results = []
    for frame_path in frame_paths:
        with Image.open(frame_path) as frame:
            frame_results.append(await run_in_threadpool(_image_scores, frame.copy(), processor, model))
    scores = [frame["synthetic_media_score"] for frame in frame_results]
    result: dict[str, Any] = {
        "sampled_frames": len(frame_results),
        "frame_synthetic_media_scores": scores,
        "mean_frame_score": float(np.mean(scores)),
        "highest_frame_score": float(np.max(scores)),
    }
    try:
        result["audio"] = await _analyze_audio(path, workdir)
    except HTTPException as exc:
        if exc.status_code != 503:
            raise
        result["audio"] = {"status": "not_analyzed", "reason": exc.detail}
    return result


def _rate_limit_key(address: str, key: str, limit: int) -> None:
    now = time.time()
    events = _rate_events[f"{key}:{address}"]
    while events and now - events[0] > 60:
        events.popleft()
    if len(events) >= limit:
        raise HTTPException(429, "Rate limit reached. Try again in a minute.")
    events.append(now)


def _rate_limit(request: Request) -> None:
    address = request.client.host if request.client else "unknown"
    _rate_limit_key(address, "media", 8)


def _audio_score(model: Any, tensor: torch.Tensor) -> float:
    with torch.inference_mode():
        return float(torch.sigmoid(model(tensor)).item())


@app.get("/")
async def home() -> FileResponse:
    return FileResponse(STATIC / "index.html")


@app.get("/share")
async def share_page() -> FileResponse:
    return FileResponse(STATIC / "index.html")


@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "location_sharing": True,
        "image_model": IMAGE_MODEL_ID,
        "audio_model_configured": PELLA_WEIGHTS.is_file(),
        "video_frame_analysis": shutil.which("ffmpeg") is not None,
        "limits": {"upload_bytes": MAX_UPLOAD, "location_ttl_seconds": SHARE_TTL},
    }


@app.post("/api/location/sessions")
async def create_location_session(body: LocationCreate, request: Request) -> dict[str, Any]:
    if not body.consent:
        raise HTTPException(400, "Explicit consent is required.")
    address = request.client.host if request.client else "unknown"
    _rate_limit_key(address, "share", 10)
    async with _shares_lock:
        _clean_expired_shares()
        if len(_shares) >= 1000:
            raise HTTPException(503, "Too many active location shares. Try again later.")
        share_id = uuid.uuid4().hex
        owner_token = secrets.token_urlsafe(32)
        viewer_token = secrets.token_urlsafe(32)
        _shares[share_id] = {
            "owner_hash": hashlib.sha256(owner_token.encode()).hexdigest(),
            "viewer_hash": hashlib.sha256(viewer_token.encode()).hexdigest(),
            "expires_at": time.time() + SHARE_TTL,
            "location": None,
            "owner": None,
            "viewers": set(),
        }
    return {"share_id": share_id, "owner_token": owner_token, "viewer_token": viewer_token, "expires_in": SHARE_TTL}


@app.websocket("/ws/location/{share_id}")
async def location_socket(websocket: WebSocket, share_id: str) -> None:
    await websocket.accept()
    try:
        auth = await asyncio.wait_for(websocket.receive_json(), timeout=10)
        role = auth.get("role")
        token = auth.get("token", "")
        async with _shares_lock:
            _clean_expired_shares()
            share = _shares.get(share_id)
            if not share:
                await websocket.close(code=4404, reason="Share expired or stopped")
                return
            expected = share["owner_hash"] if role == "owner" else share["viewer_hash"] if role == "viewer" else ""
            if not expected or not hmac.compare_digest(hashlib.sha256(token.encode()).hexdigest(), expected):
                await websocket.close(code=4403, reason="Invalid share token")
                return
            if role == "viewer":
                if len(share["viewers"]) >= 10:
                    await websocket.close(code=4429, reason="Viewer limit reached")
                    return
                share["viewers"].add(websocket)
                if share["location"]:
                    await websocket.send_json({"type": "location", "location": share["location"]})
                else:
                    await websocket.send_json({"type": "waiting"})
            else:
                previous = share.get("owner")
                share["owner"] = websocket
                if previous and previous is not websocket:
                    try:
                        await previous.close(code=4001, reason="Owner reconnected")
                    except Exception:
                        pass
                await websocket.send_json({"type": "owner-connected", "expires_at": share["expires_at"]})

        while True:
            message = await websocket.receive_json()
            if role == "viewer":
                continue
            if message.get("type") == "stop":
                async with _shares_lock:
                    stopped = _shares.pop(share_id, None)
                if stopped:
                    await _send_viewers(stopped, {"type": "stopped"})
                    for viewer in list(stopped["viewers"]):
                        try:
                            await viewer.close(code=4002, reason="Owner stopped sharing")
                        except Exception:
                            pass
                await websocket.close(code=1000)
                return
            if message.get("type") != "location":
                continue
            try:
                latitude = float(message["latitude"])
                longitude = float(message["longitude"])
                accuracy = float(message.get("accuracy", 0))
            except (KeyError, TypeError, ValueError):
                continue
            if not (-90 <= latitude <= 90 and -180 <= longitude <= 180 and 0 <= accuracy <= 100000):
                continue
            location = {"latitude": latitude, "longitude": longitude, "accuracy": accuracy, "updated_at": int(time.time())}
            async with _shares_lock:
                live_share = _shares.get(share_id)
                if not live_share or live_share.get("owner") is not websocket:
                    await websocket.close(code=4404, reason="Share expired")
                    return
                live_share["location"] = location
            await _send_viewers(live_share, {"type": "location", "location": location})
    except (WebSocketDisconnect, asyncio.TimeoutError):
        pass
    finally:
        async with _shares_lock:
            share = _shares.get(share_id)
            if share:
                if share.get("owner") is websocket:
                    share["owner"] = None
                    await _send_viewers(share, {"type": "owner-disconnected"})
                share["viewers"].discard(websocket)


@app.post("/api/detect")
async def detect_media(request: Request, file: UploadFile = File(...)) -> dict[str, Any]:
    _rate_limit(request)
    allowed = {"image/jpeg", "image/png", "image/webp", "image/avif", "audio/wav", "audio/x-wav", "audio/mpeg", "audio/mp4", "audio/ogg", "audio/webm", "video/mp4", "video/webm", "video/quicktime", "video/x-matroska"}
    if file.content_type not in allowed:
        raise HTTPException(415, "Choose a supported image, audio, or video file.")
    payload = await file.read(MAX_UPLOAD + 1)
    if not payload:
        raise HTTPException(400, "The selected file is empty.")
    if len(payload) > MAX_UPLOAD:
        raise HTTPException(413, f"File is larger than {MAX_UPLOAD // (1024 * 1024)} MB.")
    suffix = Path(file.filename or "upload").suffix[:12]
    with tempfile.TemporaryDirectory(prefix="protikar-") as tmp:
        workdir = Path(tmp)
        media_path = workdir / f"upload{suffix}"
        media_path.write_bytes(payload)
        del payload
        kind = file.content_type.split("/", 1)[0]
        if kind == "image":
            analysis = await _analyze_image(media_path)
        elif kind == "audio":
            analysis = await _analyze_audio(media_path, workdir)
        else:
            analysis = await _analyze_video(media_path, workdir)
    return {
        "status": "analysis_complete",
        "modality": kind,
        "filename": Path(file.filename or "media").name[:120],
        "analysis": analysis,
        "notice": "Experimental model output; not forensic proof. Scores can be wrong, especially for edited, compressed, non-face, or out-of-domain media.",
        "upload_retained": False,
    }


@app.on_event("startup")
async def start_expiry_sweeper() -> None:
    async def sweep() -> None:
        while True:
            await asyncio.sleep(60)
            async with _shares_lock:
                expired = [sid for sid, item in _shares.items() if time.time() >= item["expires_at"]]
                removed = [_shares.pop(sid) for sid in expired]
            for item in removed:
                await _send_viewers(item, {"type": "expired"})
    app.state.share_sweeper = asyncio.create_task(sweep())


@app.on_event("shutdown")
async def stop_expiry_sweeper() -> None:
    task = getattr(app.state, "share_sweeper", None)
    if task:
        task.cancel()

from pathlib import Path

from huggingface_hub import hf_hub_download

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)

path = hf_hub_download(
    repo_id="Sadanie/pellav2-audio-deepfake-detector",
    filename="pellav2_detector.pt",
    local_dir=MODEL_DIR,
)
print(f"Audio detector weights downloaded to {path}")

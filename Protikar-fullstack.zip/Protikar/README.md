# Protikar full-stack app

## Run locally

Python 3.11+, FFmpeg, and a working PyTorch device are required. Geolocation needs `localhost` for local development or HTTPS in deployment. WebSocket traffic must be proxied with `Upgrade` and `Connection` headers enabled.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
uvicorn server:app --host 127.0.0.1 --port 8000
```

Open `http://localhost:8000`. The facial image model downloads from Hugging Face on the first analysis request. The model is intended for face images and must not be treated as a general image authenticity test.

### Optional audio model

Download the Pellav2 audio checkpoint (about 1.26 GB):

```sh
python download_models.py
```

The optional audio model is described as a research model for studio or podcast grade English speech. It was not evaluated for singing or voice conversion and has higher false positive rates on noisy real-world audio. Read the model card before relying on its output: https://huggingface.co/Sadanie/pellav2-audio-deepfake-detector

The image detector model card: https://huggingface.co/agasta/virtus

## Docker

```sh
docker build -t protikar .
docker run --rm -p 8000:8000 -v ./models:/app/models protikar
```

Set `PELLA_WEIGHTS=/app/models/pellav2_detector.pt` in the deployment environment after downloading the optional audio checkpoint. For an Internet deployment, terminate TLS at a trusted reverse proxy and forward WebSocket upgrades to this service. Do not expose the app over plain HTTP: browser geolocation requires a secure context.

## Behavior and data handling

- A live share starts only after the owner checks consent and grants browser geolocation permission.
- The owner page must stay open for continued location updates. A private, unguessable viewer link is returned; anyone who receives that link can view the location.
- Shares expire after two hours, are held in server memory only, and are removed when the owner stops sharing, the TTL expires, or the server restarts. No location history is written to disk.
- Analysis requires a separate upload consent. A file is stored in a temporary directory, model inference runs, and the directory is deleted at the end of the request. The upload size is limited to 50 MB by default.
- Images are scored with the configured face-image classification model. Videos are screened using up to eight sampled frames and, when the optional audio detector is configured, a four-second audio segment. Audio-only files require the optional checkpoint.
- Model scores are uncertain signals, not proof of authenticity. The API reports unavailable analysis rather than inventing a result when a required model or decoder is unavailable.
- This app is separate from the static WebsitePublisher site. It requires an HTTPS host that supports Python ASGI and WebSockets before it can be used as a public service.

## Environment

Copy `.env.example` to `.env` for reference, then export the values in your process manager. The app does not load `.env` files automatically.

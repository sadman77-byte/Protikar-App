(() => {
  const start = document.querySelector('#start');
  const stop = document.querySelector('#stop');
  const copy = document.querySelector('#copy');
  const consent = document.querySelector('#consent');
  const status = document.querySelector('#status');
  const feedback = document.querySelector('#feedback');
  const card = document.querySelector('#location-card');
  let currentLocation = null;

  const say = (message) => { feedback.textContent = message; };
  const setReady = (active) => {
    status.classList.toggle('active', active);
    status.lastChild.textContent = active ? ' Ready to share' : ' Location not loaded';
    stop.hidden = !active;
    copy.hidden = !active;
    start.hidden = active;
  };
  const clearLocation = (message = 'Location cleared from this page. Any link you already sent cannot be recalled here.') => {
    currentLocation = null;
    card.hidden = true;
    card.replaceChildren();
    setReady(false);
    say(message);
  };

  start.addEventListener('click', () => {
    if (!consent.checked) {
      say('Please confirm that you want to share your location before continuing.');
      consent.focus();
      return;
    }
    if (!navigator.geolocation) {
      say('This browser does not support location access.');
      return;
    }
    start.disabled = true;
    say('Waiting for your browser’s location permission…');
    navigator.geolocation.getCurrentPosition((position) => {
      const { latitude, longitude, accuracy } = position.coords;
      currentLocation = { latitude, longitude, accuracy, time: new Date() };
      const recipient = document.querySelector('#recipient').value.trim();
      const mapUrl = `https://maps.google.com/?q=${latitude},${longitude}`;
      card.replaceChildren();
      const who = document.createElement('strong');
      who.textContent = recipient ? `Location for ${recipient}: ` : 'Your location: ';
      const link = document.createElement('a');
      link.href = mapUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = 'Open map ↗';
      const detail = document.createElement('span');
      detail.textContent = `  ·  ±${Math.round(accuracy)} m accuracy  ·  captured ${currentLocation.time.toLocaleTimeString()}`;
      card.append(who, link, detail);
      card.hidden = false;
      setReady(true);
      say('Location captured on this device. Select Share map link to choose how and with whom to share it. This is a one-time snapshot.');
      start.disabled = false;
    }, (error) => {
      const messages = { 1: 'Location permission was denied. You can allow it in your browser settings.', 2: 'Your location could not be determined. Try again where GPS or network location is available.', 3: 'Location request timed out. Please try again.' };
      say(messages[error.code] || 'Could not access location. Please try again.');
      start.disabled = false;
    }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
  });

  copy.addEventListener('click', async () => {
    if (!currentLocation) return;
    const { latitude, longitude } = currentLocation;
    const message = `My location: https://maps.google.com/?q=${latitude},${longitude}`;
    try {
      if (navigator.share) await navigator.share({ title: 'My location', text: message });
      else { await navigator.clipboard.writeText(message); say('Location link copied. Send it only to the person you chose.'); }
    } catch (error) {
      if (error.name !== 'AbortError') say('Could not share automatically. You can open the map and share it yourself.');
    }
  });
  stop.addEventListener('click', () => clearLocation());

  const mediaInput = document.querySelector('#media-file');
  const mediaResult = document.querySelector('#media-result');
  const formatBytes = (bytes) => bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(1)} KB` : `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  const addMediaItem = (label, value) => {
    const item = document.createElement('div');
    item.className = 'media-item';
    const title = document.createElement('span');
    title.textContent = label;
    const content = document.createElement('strong');
    content.textContent = value;
    item.append(title, content);
    mediaResult.append(item);
  };

  mediaInput.addEventListener('change', async () => {
    const file = mediaInput.files && mediaInput.files[0];
    if (!file) return;
    mediaResult.hidden = false;
    mediaResult.replaceChildren();
    if (file.size > 100 * 1024 * 1024) {
      addMediaItem('Inspection', 'File exceeds the 100 MB limit.');
      return;
    }
    addMediaItem('File', file.name);
    addMediaItem('MIME type', file.type || 'Not provided');
    addMediaItem('Size', formatBytes(file.size));
    addMediaItem('Last modified', new Date(file.lastModified).toLocaleString());
    addMediaItem('Inspection', 'Reading media properties…');

    try {
      const digest = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());
      const hash = [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
      mediaResult.lastElementChild.remove();
      addMediaItem('SHA-256', hash);
    } catch {
      mediaResult.lastElementChild.remove();
      addMediaItem('SHA-256', 'Not available in this browser context');
    }

    const kind = file.type.split('/')[0];
    if (kind === 'image') {
      const image = new Image();
      image.onload = () => { addMediaItem('Dimensions', `${image.naturalWidth} × ${image.naturalHeight} px`); URL.revokeObjectURL(image.src); };
      image.onerror = () => addMediaItem('Dimensions', 'Could not read image dimensions');
      image.src = URL.createObjectURL(file);
    } else if (kind === 'audio' || kind === 'video') {
      const media = document.createElement(kind);
      media.preload = 'metadata';
      media.onloadedmetadata = () => {
        addMediaItem('Duration', `${Math.floor(media.duration / 60)}:${String(Math.floor(media.duration % 60)).padStart(2, '0')}`);
        if (kind === 'video') addMediaItem('Dimensions', `${media.videoWidth} × ${media.videoHeight} px`);
        URL.revokeObjectURL(media.src);
      };
      media.onerror = () => addMediaItem('Media properties', 'Could not read duration or dimensions');
      media.src = URL.createObjectURL(file);
    }
  });
})();

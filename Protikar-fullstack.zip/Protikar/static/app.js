(() => {
  const $ = (selector) => document.querySelector(selector);
  const status = $('#location-status-text');
  const statusPill = $('#location-status');
  const feedback = $('#location-feedback');
  const startButton = $('#start-live');
  const stopButton = $('#stop-live');
  const copyButton = $('#copy-live-link');
  const consent = $('#location-consent');
  const mapLink = $('#map-link');
  const mapUpdated = $('#map-updated');
  const ownerControls = $('#owner-controls');
  const viewerMessage = $('#viewer-message');
  let map;
  let marker;
  let accuracyCircle;
  let socket;
  let watchId = null;
  let shareInfo = null;
  let isViewer = false;

  function setLocationStatus(message, active = false) {
    status.textContent = message;
    statusPill.classList.toggle('active', active);
  }

  function initMap() {
    if (!window.L || map) return;
    map = L.map('map', { scrollWheelZoom: false }).setView([20, 0], 2);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    window.setTimeout(() => map.invalidateSize(), 150);
  }

  function showLocation(location, owner = false) {
    initMap();
    if (!map) return;
    const point = [location.latitude, location.longitude];
    if (!marker) marker = L.marker(point).addTo(map);
    else marker.setLatLng(point);
    if (!accuracyCircle) accuracyCircle = L.circle(point, { radius: location.accuracy || 0, color: '#46b97a', fillColor: '#a7efc4', fillOpacity: 0.12, weight: 1 }).addTo(map);
    else accuracyCircle.setLatLng(point).setRadius(location.accuracy || 0);
    map.setView(point, Math.max(map.getZoom(), 15));
    const mapsUrl = `https://www.google.com/maps?q=${location.latitude},${location.longitude}`;
    mapLink.href = mapsUrl;
    mapLink.hidden = false;
    mapUpdated.textContent = `${owner ? 'Your location' : 'Shared location'} · ±${Math.round(location.accuracy || 0)} m · ${new Date(location.updated_at * 1000 || Date.now()).toLocaleTimeString()}`;
  }

  function openSocket(shareId, token, role) {
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${location.host}/ws/location/${encodeURIComponent(shareId)}`);
    ws.addEventListener('open', () => ws.send(JSON.stringify({ type: 'auth', role, token })));
    return ws;
  }

  function createViewerLink(share) {
    return `${location.origin}/share#${share.share_id}.${share.viewer_token}`;
  }

  function showViewerMode() {
    const raw = location.hash.slice(1);
    const separator = raw.indexOf('.');
    if (separator < 1) return false;
    const shareId = raw.slice(0, separator);
    const token = raw.slice(separator + 1);
    if (!/^[0-9a-f]{32}$/.test(shareId) || token.length < 30) return false;
    isViewer = true;
    ownerControls.hidden = true;
    viewerMessage.hidden = false;
    viewerMessage.textContent = 'Joining this private location share…';
    $('#location-title').textContent = 'Live shared location';
    $('#location-explainer').textContent = 'This private link shows live location updates from the person who shared it. It stops when the owner revokes sharing or the link expires.';
    setLocationStatus('Connecting', false);
    socket = openSocket(shareId, token, 'viewer');
    socket.addEventListener('message', (event) => {
      const message = JSON.parse(event.data);
      if (message.type === 'waiting') viewerMessage.textContent = 'Connected. Waiting for the owner to share their first location.';
      if (message.type === 'location') {
        viewerMessage.hidden = true;
        setLocationStatus('Live update', true);
        showLocation(message.location);
      }
      if (['stopped', 'expired'].includes(message.type)) {
        viewerMessage.hidden = false;
        viewerMessage.textContent = message.type === 'stopped' ? 'The owner stopped sharing and revoked this link.' : 'This location share has expired.';
        setLocationStatus('Share ended', false);
      }
      if (message.type === 'owner-disconnected') {
        viewerMessage.hidden = false;
        viewerMessage.textContent = 'The owner is offline. The last location remains visible until the share ends or expires.';
        setLocationStatus('Owner offline', false);
      }
    });
    socket.addEventListener('close', (event) => {
      if (event.code === 4403 || event.code === 4404) {
        viewerMessage.hidden = false;
        viewerMessage.textContent = 'This link is invalid, revoked, or expired.';
        setLocationStatus('Unavailable', false);
      }
    });
    socket.addEventListener('error', () => {
      viewerMessage.hidden = false;
      viewerMessage.textContent = 'Could not connect to the live share. Check your connection and try again.';
    });
    return true;
  }

  function startPositionWatch() {
    if (!navigator.geolocation) {
      feedback.textContent = 'This browser does not support location access.';
      return;
    }
    watchId = navigator.geolocation.watchPosition((position) => {
      const locationData = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy
      };
      showLocation({ ...locationData, updated_at: Math.floor(Date.now() / 1000) }, true);
      if (socket && socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ type: 'location', ...locationData }));
      feedback.textContent = 'Sharing live. Keep this page open; select Stop and revoke link when finished.';
      setLocationStatus('Live sharing', true);
    }, (error) => {
      const descriptions = { 1: 'Location permission was denied. Allow it in your browser settings to start sharing.', 2: 'Your device could not determine a location.', 3: 'Location request timed out. Try again.' };
      feedback.textContent = descriptions[error.code] || 'Could not read your location.';
      if (shareInfo) stopLive(true);
    }, { enableHighAccuracy: true, maximumAge: 3000, timeout: 20000 });
  }

  async function startLive() {
    if (!consent.checked) {
      feedback.textContent = 'Check the consent box before starting live sharing.';
      consent.focus();
      return;
    }
    startButton.disabled = true;
    feedback.textContent = 'Creating a private, expiring share…';
    try {
      const response = await fetch('/api/location/sessions', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ consent: true })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Could not create a share.');
      shareInfo = data;
      socket = openSocket(data.share_id, data.owner_token, 'owner');
      socket.addEventListener('open', () => {}, { once: true });
      socket.addEventListener('message', (event) => {
        const message = JSON.parse(event.data);
        if (message.type === 'owner-connected') {
          startPositionWatch();
          startButton.hidden = true;
          stopButton.hidden = false;
          copyButton.hidden = false;
          feedback.textContent = 'Waiting for a location fix… The viewer link expires in two hours.';
        }
      });
      socket.addEventListener('close', () => {
        if (shareInfo) {
          if (watchId !== null) navigator.geolocation.clearWatch(watchId);
          watchId = null;
          shareInfo = null;
          startButton.hidden = false;
          stopButton.hidden = true;
          copyButton.hidden = true;
          setLocationStatus('Disconnected', false);
          feedback.textContent = 'The live connection closed. Start a new share to reconnect.';
        }
      });
    } catch (error) {
      feedback.textContent = error.message;
      startButton.disabled = false;
    }
  }

  function stopLive(silent = false) {
    if (watchId !== null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
    watchId = null;
    if (socket && socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ type: 'stop' }));
    socket = null;
    shareInfo = null;
    startButton.hidden = false;
    startButton.disabled = false;
    stopButton.hidden = true;
    copyButton.hidden = true;
    consent.checked = false;
    setLocationStatus('Not sharing', false);
    if (!silent) feedback.textContent = 'Sharing stopped. The viewer link has been revoked.';
  }

  function addResult(label, value) {
    const item = document.createElement('div');
    item.className = 'media-item';
    const key = document.createElement('span');
    key.textContent = label;
    const result = document.createElement('strong');
    result.textContent = value;
    item.append(key, result);
    $('#media-result').append(item);
  }

  async function analyzeMedia() {
    const file = $('#media-file').files[0];
    if (!file || !$('#media-consent').checked) return;
    const button = $('#analyze-media');
    const result = $('#media-result');
    button.disabled = true;
    result.hidden = true;
    result.replaceChildren();
    $('#media-feedback').textContent = 'Uploading for temporary server-side analysis…';
    try {
      const form = new FormData();
      form.append('file', file, file.name);
      const response = await fetch('/api/detect', { method: 'POST', body: form });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Analysis failed.');
      addResult('Modality', data.modality);
      addResult('File', data.filename);
      const analysis = data.analysis;
      if (analysis.synthetic_media_score !== undefined) addResult('Synthetic-media model score', `${(analysis.synthetic_media_score * 100).toFixed(1)}%`);
      if (analysis.synthetic_speech_score !== undefined) addResult('Synthetic-speech model score', `${(analysis.synthetic_speech_score * 100).toFixed(1)}%`);
      if (analysis.mean_frame_score !== undefined) {
        addResult('Mean sampled-frame score', `${(analysis.mean_frame_score * 100).toFixed(1)}%`);
        addResult('Frames sampled', String(analysis.sampled_frames));
      }
      if (analysis.audio) addResult('Audio track', analysis.audio.status === 'not_analyzed' ? analysis.audio.reason : `Speech score ${(analysis.audio.synthetic_speech_score * 100).toFixed(1)}%`);
      if (analysis.class_scores) analysis.class_scores.forEach((entry) => addResult(`Class: ${entry.label}`, `${(entry.score * 100).toFixed(1)}%`));
      addResult('Interpretation', 'Experimental model output only; not forensic proof.');
      result.hidden = false;
      $('#media-feedback').textContent = 'Analysis complete. The server deleted the temporary upload.';
    } catch (error) {
      $('#media-feedback').textContent = error.message;
    } finally {
      button.disabled = !($('#media-file').files[0] && $('#media-consent').checked);
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    initMap();
    if (!showViewerMode()) {
      startButton.addEventListener('click', startLive);
      stopButton.addEventListener('click', () => stopLive());
      copyButton.addEventListener('click', async () => {
        if (!shareInfo) return;
        const link = createViewerLink(shareInfo);
        try { await navigator.clipboard.writeText(link); feedback.textContent = 'Private viewer link copied. Send it only to the person you choose.'; }
        catch { window.prompt('Copy this private viewer link:', link); }
      });
    }
    $('#media-file').addEventListener('change', () => {
      const file = $('#media-file').files[0];
      $('#file-label').textContent = file ? file.name : 'Choose media to screen';
      $('#media-feedback').textContent = file ? `${(file.size / (1024 * 1024)).toFixed(2)} MB · selected locally until you analyze` : 'No file selected.';
      $('#analyze-media').disabled = !file || !$('#media-consent').checked;
    });
    $('#media-consent').addEventListener('change', () => { $('#analyze-media').disabled = !$('#media-file').files[0] || !$('#media-consent').checked; });
    $('#analyze-media').addEventListener('click', analyzeMedia);
    fetch('/api/health').then((response) => response.json()).then((health) => {
      if (!health.audio_model_configured) $('#media-feedback').textContent = 'Image/video frame model loads on first request. Audio model is unavailable until its optional checkpoint is installed.';
    }).catch(() => {});
  });
})();
